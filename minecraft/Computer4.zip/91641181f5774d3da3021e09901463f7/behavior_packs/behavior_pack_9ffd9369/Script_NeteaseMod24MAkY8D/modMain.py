# -*- coding: utf-8 -*-

from mod.common.mod import Mod


@Mod.Binding(name="Script_NeteaseMod24MAkY8D", version="0.0.1")
class Script_NeteaseMod24MAkY8D(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def Script_NeteaseMod24MAkY8DServerInit(self):
        pass

    @Mod.DestroyServer()
    def Script_NeteaseMod24MAkY8DServerDestroy(self):
        pass

    @Mod.InitClient()
    def Script_NeteaseMod24MAkY8DClientInit(self):
        pass

    @Mod.DestroyClient()
    def Script_NeteaseMod24MAkY8DClientDestroy(self):
        pass
